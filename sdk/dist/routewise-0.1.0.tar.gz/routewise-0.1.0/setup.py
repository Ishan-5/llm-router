from setuptools import setup, find_packages

setup(
    name="routewise",
    version="0.1.0",
    description="Client SDK for the routewise cost-aware LLM router",
    packages=find_packages(),
    install_requires=["requests"],
    python_requires=">=3.8",
)